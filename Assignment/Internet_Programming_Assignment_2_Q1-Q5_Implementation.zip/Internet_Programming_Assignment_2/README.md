# Internet Programming – Assignment 2 (Q1–Q5)

This package contains five separate practical implementations based on the supplied assignment sheet.

## Requirements
- A modern browser (Chrome recommended)
- Visual Studio Code (recommended)
- VS Code Live Server extension for Q1, Q2, Q3 and Q5
- Node.js + TypeScript compiler (`tsc`) only if you want to recompile Q4. A ready-to-run compiled JavaScript file is included.

## Run the projects
1. Extract the ZIP.
2. Open the extracted `Internet_Programming_Assignment_2` folder in VS Code.
3. For Q1, Q2, Q3 and Q5: right-click the relevant `index.html` and choose **Open with Live Server**.
4. For Q4: open `Q4_TypeScript_Student_System/index.html` with Live Server. The browser runs the included compiled `student.js`.

## Question-by-question guide

### Q1 – Student Registration Validation
Enter a name, email, 10-digit Indian mobile number and password. Submit the form to see inline validation errors or a success message. The page does not reload.
Password rule used in this implementation: at least 8 characters, one uppercase letter, one lowercase letter, one digit and one special character.

### Q2 – E-commerce Dynamic Product Search
Type a product name or category. The page uses `fetch()` (AJAX) to retrieve `products.json` and dynamically displays matching product cards. The JSON file is served locally by Live Server, acting as the local data endpoint for this demonstration.

### Q3 – XMLHttpRequest and AJAX
The page explains the XMLHttpRequest object, readyState values and callback/event methods. Click **Load sample data** to make an actual XMLHttpRequest to `sample-data.txt`; the response appears without reloading the page.

### Q4 – TypeScript Student Management System
The source file `student.ts` defines a `Student` class with properties, a constructor and a display method. `student.js` is the compiled browser-ready output. The page demonstrates creating and displaying a student record.
To recompile (optional): install TypeScript with `npm install -g typescript`, then run `tsc` inside this folder.

### Q5 – Online Banking Form Validation
Validates account number, mobile number and email using regular expressions. Account number format is assumed to be 9–18 digits because the assignment does not specify an exact bank-specific format. Mobile number uses a 10-digit Indian format.

## Evidence/screenshots to capture
- Q1: empty/invalid submission showing field errors; successful valid submission.
- Q2: search results for a product; no-results state.
- Q3: XMLHttpRequest response loaded; optionally show the DevTools Network request.
- Q4: student details displayed in the page; show `student.ts` source in VS Code.
- Q5: invalid field messages; successful validation result.

## Important notes
- These are educational demonstrations. They do not connect to a real bank, payment service, student database or production e-commerce server.
- The AJAX examples require a local web server such as Live Server; opening HTML directly using `file://` may block local data requests.
- For Q2, the assignment asks for product details in JSON format from a server. Here, Live Server serves the included `products.json` file as the local JSON endpoint.
- Q3 uses the classic `XMLHttpRequest` object as specifically requested.
