const button=document.getElementById('loadBtn');
button.addEventListener('click',()=>{
 const xhr=new XMLHttpRequest();
 const status=document.getElementById('requestStatus');
 const responseBox=document.getElementById('response');
 const log=document.getElementById('stateLog');
 const states=[];
 responseBox.textContent='Waiting for server response…';
 status.textContent='Request sent.';
 xhr.onreadystatechange=()=>{
  states.push(`readyState = ${xhr.readyState}`);
  log.textContent=states.join('\n');
  if(xhr.readyState===XMLHttpRequest.DONE){
   if(xhr.status===200){status.textContent=`Success: HTTP ${xhr.status}`;responseBox.textContent=xhr.responseText;}
   else{status.textContent=`Request failed: HTTP ${xhr.status}. Run with Live Server.`;responseBox.textContent='Unable to load sample-data.txt.';}
  }
 };
 xhr.onerror=()=>{status.textContent='Network error. Make sure Live Server is running.';};
 xhr.open('GET','sample-data.txt',true);
 xhr.send();
});