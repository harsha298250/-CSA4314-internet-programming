const searchInput=document.getElementById('search');
const results=document.getElementById('results');
const statusText=document.getElementById('status');
let products=[];
async function loadProducts(){
 statusText.textContent='Loading product data from products.json…';
 try{
  const response=await fetch('./products.json');
  if(!response.ok) throw new Error(`HTTP ${response.status}`);
  const data=await response.json();
  products=data.products||[];
  statusText.textContent=`Loaded ${products.length} products. Type to filter the catalogue.`;
 }catch(error){
  statusText.textContent='Could not load products.json. Run this page with Live Server, not file://.';
  console.error('AJAX product request failed:',error);
 }
}
function render(list){
 results.innerHTML='';
 if(!list.length){results.innerHTML='<div class="panel">No matching products found. Try another search.</div>';return;}
 list.forEach(product=>{
  const card=document.createElement('article');card.className='product';
  const category=document.createElement('div');category.className='category';category.textContent=product.category;
  const title=document.createElement('h3');title.textContent=product.name;
  const description=document.createElement('p');description.textContent=product.description;
  const price=document.createElement('div');price.className='price';price.textContent=`₹${product.price.toLocaleString('en-IN')}`;
  card.append(category,title,description,price);results.append(card);
 });
}
searchInput.addEventListener('input',()=>{
 const term=searchInput.value.trim().toLowerCase();
 const filtered=products.filter(p=>`${p.name} ${p.category} ${p.description}`.toLowerCase().includes(term));
 render(filtered);
 statusText.textContent=`Showing ${filtered.length} of ${products.length} products.`;
});
loadProducts();