const form=document.getElementById('registrationForm');
const rules={
 name:/^[A-Za-z][A-Za-z .'-]{1,49}$/,
 email:/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/,
 mobile:/^[6-9]\d{9}$/,
 password:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/
};
function showError(id,message){document.getElementById(id).textContent=message}
form.addEventListener('submit',(event)=>{
 event.preventDefault();
 const values={name:document.getElementById('studentName').value.trim(),email:document.getElementById('email').value.trim(),mobile:document.getElementById('mobile').value.trim(),password:document.getElementById('password').value};
 let valid=true;
 const checks=[
  ['nameError',rules.name.test(values.name),'Enter a valid name (2–50 characters).'],
  ['emailError',rules.email.test(values.email),'Enter a valid email address.'],
  ['mobileError',rules.mobile.test(values.mobile),'Enter a valid 10-digit Indian mobile number.'],
  ['passwordError',rules.password.test(values.password),'Password must meet all the rules shown above.']
 ];
 checks.forEach(([id,ok,msg])=>{showError(id,ok?'':msg);if(!ok)valid=false});
 const message=document.getElementById('formMessage');
 if(valid){message.className='success';message.textContent=`Registration details validated successfully for ${values.name}. (Demo only; no data was submitted.)`;}
 else{message.className='error';message.textContent='Please correct the highlighted fields and submit again.';}
});