const form=document.getElementById('bankForm');
const patterns={
 account:/^\d{9,18}$/,
 mobile:/^[6-9]\d{9}$/,
 email:/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
};
form.addEventListener('submit',(event)=>{
 event.preventDefault();
 const values={
  account:document.getElementById('account').value.trim(),
  mobile:document.getElementById('mobile').value.trim(),
  email:document.getElementById('email').value.trim()
 };
 const messages={
  account:'Account number must contain 9–18 digits.',
  mobile:'Enter a valid 10-digit Indian mobile number.',
  email:'Enter a valid email address.'
 };
 let valid=true;
 Object.keys(patterns).forEach(key=>{
  const ok=patterns[key].test(values[key]);
  document.getElementById(`${key}Error`).textContent=ok?'':messages[key];
  if(!ok)valid=false;
 });
 const result=document.getElementById('result');
 result.className=valid?'success':'error';
 result.textContent=valid?'All details are valid. (Educational demo only; no banking transaction was performed.)':'Please correct the invalid fields.';
});