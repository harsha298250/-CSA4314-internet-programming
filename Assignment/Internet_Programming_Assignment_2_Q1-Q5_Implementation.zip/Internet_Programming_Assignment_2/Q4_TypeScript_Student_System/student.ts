// Assignment 2 – Q4: TypeScript class and object
class Student {
    name: string;
    registerNumber: string;
    department: string;
    marks: number;

    constructor(name: string, registerNumber: string, department: string, marks: number) {
        this.name = name;
        this.registerNumber = registerNumber;
        this.department = department;
        this.marks = marks;
    }

    displayStudentDetails(): string {
        return `Name: ${this.name}\nRegister Number: ${this.registerNumber}\nDepartment: ${this.department}\nMarks: ${this.marks}`;
    }
}

const student = new Student("Arun Kumar", "24CSE102", "Computer Science and Engineering", 88);
const output = document.getElementById("studentOutput");
if (output) {
    const details: [string, string][] = [
        ["Student Name", student.name],
        ["Register Number", student.registerNumber],
        ["Department", student.department],
        ["Marks", `${student.marks} / 100`]
    ];
    output.innerHTML = details.map(([label, value]) =>
        `<div class="detail"><span>${label}</span><strong>${value}</strong></div>`
    ).join("");
    console.log(student.displayStudentDetails());
}
