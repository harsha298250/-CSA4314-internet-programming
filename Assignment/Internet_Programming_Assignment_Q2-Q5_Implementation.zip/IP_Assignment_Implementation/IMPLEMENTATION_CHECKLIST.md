# Practical Demonstration Checklist (Q2–Q5)

## Q2 – Photographer page
- [ ] Open `Q2_Photographer/index.html` using a local server.
- [ ] Resize browser to show responsive gallery.
- [ ] Point out inline CSS in the hero image/element styling if adding a sample inline style for viva; embedded CSS in the `<style>` block; and external CSS in `styles.css`.
- [ ] Explain cascade order, selector specificity and inherited font/color properties.

## Q3 – CSS3 showcase
- [ ] Explain layered `background` gradients.
- [ ] Explain `border-image` and its slice value.
- [ ] Explain HEX/HSL colors and alpha transparency.
- [ ] Explain `box-shadow` and `text-shadow`.

## Q4 – Transformations and animation
- [ ] Hover each 2D transform card.
- [ ] Observe the 3D cube and explain `perspective` and `transform-style: preserve-3d`.
- [ ] Hover/focus the transition button.
- [ ] Show the `@keyframes` rules and marquee animation.

## Q5 – PWA
- [ ] Serve the folder on localhost or HTTPS.
- [ ] Open DevTools → Application → Manifest and Service Workers.
- [ ] Reload once while online so app shell is cached.
- [ ] Switch DevTools Network to Offline and reload.
- [ ] Test Save note and Test notification.
- [ ] Explain that the demo notification is local; real push requires server-side push subscription and VAPID configuration.
