# Internet Programming – Practical Implementations (Q2–Q5)

This package contains four separate, browser-ready practicals aligned with the assignment brief.

## Contents
- **Q2_Photographer** – photographer portfolio demonstrating inline, embedded and external CSS, cascading, specificity and inheritance.
- **Q3_CSS3_Showcase** – backgrounds, border images, colors, box shadows and text effects.
- **Q4_Transforms_Animations** – 2D/3D transforms, transitions, CSS keyframes and a marquee-style animation.
- **Q5_PWA** – installable Progressive Web App with a web app manifest, service worker, offline caching and a local notification demonstration.

## Run the projects
A local web server is required for all projects, and especially Q5 (service workers do not work from `file://`).

### Option A: VS Code Live Server
1. Extract this ZIP.
2. Open the extracted `IP_Assignment_Implementation` folder in VS Code.
3. Install/enable the **Live Server** extension if needed.
4. Right-click the required project's `index.html` and choose **Open with Live Server**.

### Option B: Python
Open a terminal in the extracted `IP_Assignment_Implementation` folder and run:

```bash
python -m http.server 5500
```

Then open:
- Q2: http://localhost:5500/Q2_Photographer/
- Q3: http://localhost:5500/Q3_CSS3_Showcase/
- Q4: http://localhost:5500/Q4_Transforms_Animations/
- Q5: http://localhost:5500/Q5_PWA/

Stop the server with `Ctrl+C`.

## Q5 PWA notes
- Use `http://localhost` or HTTPS. Service workers are not available from a normal `file://` URL.
- The Install button is shown when the browser supports the install prompt; otherwise use the browser menu's **Install app** / **Add to Home Screen** option when available.
- The notification button requests permission and displays a **local browser notification**. True remote push notifications require a push service, application server and VAPID keys; those cannot be completed by a static front-end ZIP alone.
- To test offline mode: open Q5 once while online, wait for the page to load, then switch the browser to offline in DevTools and refresh. The cached app shell should remain available.

## Suggested evidence screenshots for submission
1. Q2: full photographer page; DevTools/source showing inline `style`, embedded `<style>`, and linked `styles.css`.
2. Q3: background/border-image/shadow/text-effects cards.
3. Q4: transformed cards at rest and hover; marquee moving; animation examples.
4. Q5: app loaded, manifest/install prompt (if supported), notification permission/result, and offline reload.

## Academic note
Use these implementations as practical demonstrations and write your own explanations in the assignment document. Add your name/register number where required. The projects are self-contained and use no external libraries or build tools.
