const $ = (id) => document.getElementById(id);
const noteInput = $('noteInput');
const message = $('message');
const savedNote = $('savedNote');

function showSavedNote() {
  const note = localStorage.getItem('fieldnotes-note');
  if (note) { savedNote.textContent = `Saved note: ${note}`; savedNote.style.display = 'block'; }
}
$('saveBtn').addEventListener('click', () => {
  const value = noteInput.value.trim();
  if (!value) { message.textContent = 'Type a note before saving.'; return; }
  localStorage.setItem('fieldnotes-note', value);
  savedNote.textContent = `Saved note: ${value}`;
  savedNote.style.display = 'block';
  message.textContent = 'Your note was saved in this browser.';
  noteInput.value = '';
});
showSavedNote();

function updateConnection() {
  const online = navigator.onLine;
  $('connectionDot').style.background = online ? '#3b9564' : '#d36b55';
  $('connectionText').textContent = online ? 'Online' : 'Offline mode';
}
window.addEventListener('online', updateConnection);
window.addEventListener('offline', updateConnection);
updateConnection();

$('notifyBtn').addEventListener('click', async () => {
  if (!('Notification' in window)) { message.textContent = 'Notifications are not supported in this browser.'; return; }
  const permission = await Notification.requestPermission();
  if (permission === 'granted') {
    new Notification('FieldNotes', { body: 'Your local notification test is working.' });
    message.textContent = 'Local notification displayed. Remote push needs a server and push subscription.';
  } else {
    message.textContent = `Notification permission: ${permission}. You can enable it in site settings.`;
  }
});

let installPrompt = null;
const installBtn = $('installBtn');
window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault(); installPrompt = event; installBtn.hidden = false;
});
installBtn.addEventListener('click', async () => {
  if (!installPrompt) return;
  installPrompt.prompt();
  await installPrompt.userChoice;
  installPrompt = null; installBtn.hidden = true;
});
window.addEventListener('appinstalled', () => { installBtn.hidden = true; message.textContent = 'FieldNotes was installed.'; });

if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      await navigator.serviceWorker.register('./sw.js');
      $('swStatus').textContent = 'Service worker registered';
    } catch (error) {
      $('swStatus').textContent = 'Service worker registration failed';
      console.error('Service worker error:', error);
    }
  });
} else {
  $('swStatus').textContent = 'Service workers unsupported';
}
